#trial.py#
This script tests the true positive and false positive numbers based on some trained sets you give it. Within the samples directory there is a nude and not_nude directory. Put your jpgs in the correct folder and run trial.py. 

Add the `-r` option if you want the pictures to be resized before being tested.